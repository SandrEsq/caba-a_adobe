"""
init_db.py — Base de datos SQLite para el POS "La Cabaña de Adobe" (FastAPI).

Uso:
    python init_db.py
Genera `cabana_final.db` en el mismo directorio.
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "cabana_final.db")

def crear_bd():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Meseros / usuarios
    cur.execute("""
        CREATE TABLE meseros (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE NOT NULL,
            nombre TEXT NOT NULL,
            rol TEXT NOT NULL DEFAULT 'MESERO',
            activo INTEGER NOT NULL DEFAULT 1
        );
    """)

    # Menú por categorías
    cur.execute("""
        CREATE TABLE menu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            categoria TEXT NOT NULL,
            emoji TEXT NOT NULL,
            disponible INTEGER NOT NULL DEFAULT 1
        );
    """)

    # Extras (costo adicional)
    cur.execute("""
        CREATE TABLE extras (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL
        );
    """)

    # Pedidos
    cur.execute("""
        CREATE TABLE pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mesa INTEGER NOT NULL,
            zona TEXT NOT NULL,
            mesero_id INTEGER NOT NULL,
            estado TEXT NOT NULL DEFAULT 'PENDIENTE',
            total REAL NOT NULL DEFAULT 0,
            fecha TEXT NOT NULL,
            FOREIGN KEY (mesero_id) REFERENCES meseros(id)
        );
    """)

    # Detalle de pedido (con nota para platillos personalizados)
    cur.execute("""
        CREATE TABLE detalle_pedido (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER NOT NULL,
            menu_id INTEGER,          -- NULL si es platillo personalizado
            cantidad INTEGER NOT NULL,
            precio_unitario REAL,     -- para personalizados
            nombre_personalizado TEXT, -- nombre si no está en menú
            nota TEXT,                -- notas (ej. sin cebolla)
            FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
            FOREIGN KEY (menu_id) REFERENCES menu(id)
        );
    """)

    # Pagos
    cur.execute("""
        CREATE TABLE pagos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER NOT NULL,
            metodo_pago TEXT NOT NULL,
            monto REAL NOT NULL,
            fecha TEXT NOT NULL,
            FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
        );
    """)

    # Meseros de prueba
    cur.execute("INSERT INTO meseros (token, nombre, rol, activo) VALUES ('4512','Carlos','MESERO',1);")
    cur.execute("INSERT INTO meseros (token, nombre, rol, activo) VALUES ('7845','Ana','MESERO',1);")
    cur.execute("INSERT INTO meseros (token, nombre, rol, activo) VALUES ('9999','Administrador','ADMIN',1);")

    # Menú real completo (mismo que antes)
    menu = [
        ("Plato de Birria", 160, "Platillos Fuertes", "🍽️"),
        ("Plato de Pancita", 150, "Platillos Fuertes", "🍽️"),
        ("Mixiote de Carnero", 155, "Platillos Fuertes", "🍽️"),
        ("Parrillada 2 personas", 370, "Parrilladas", "🍽️"),
        ("Parrillada 4 personas", 685, "Parrilladas", "🍽️"),
        ("Parrillada 6 personas", 875, "Parrilladas", "🍽️"),
        ("Quesabirria", 65, "Parrilladas", "🍽️"),
        ("Suadero", 40, "Tacos", "🍽️"),
        ("Longaniza", 40, "Tacos", "🍽️"),
        ("Enchilada", 40, "Tacos", "🍽️"),
        ("Pechuga", 40, "Tacos", "🍽️"),
        ("Arrachera", 65, "Tacos", "🍽️"),
        ("Chistorra", 45, "Tacos", "🍽️"),
        ("Chorizo Arg", 45, "Tacos", "🍽️"),
        ("Cecina", 55, "Tacos", "🍽️"),
        ("Birria", 50, "Tacos", "🍽️"),
        ("Costilla", 55, "Tacos", "🍽️"),
        ("Guacamole c/chicharrón", 75, "Complementos", "🍽️"),
        ("Frijoles refritos c/totopos", 35, "Complementos", "🍽️"),
        ("Papas asadas", 45, "Complementos", "🍽️"),
        ("Orden de nopales", 45, "Complementos", "🍽️"),
        ("Orden de cebollitas", 45, "Complementos", "🍽️"),
        ("Aguacate 1 pza", 35, "Complementos", "🍽️"),
        ("Quesadillas 3 pzas", 65, "Complementos", "🍽️"),
        ("Sopecitos 3 pzas", 65, "Complementos", "🍽️"),
        ("Consomé de Birria", 20, "Complementos", "🍽️"),
        ("Quesadillas", 35, "Antojitos", "🍽️"),
        ("Huarache", 140, "Antojitos", "🍽️"),
        ("Choriqueso", 120, "Antojitos", "🍽️"),
        ("Jarra 2 L", 90, "Agua de Fruta", "🍽️"),
        ("Jarra 1 L", 65, "Agua de Fruta", "🍽️"),
        ("Vaso 500 ml", 35, "Agua de Fruta", "🍽️"),
        ("Heineken", 55, "Cervezas", "🍽️"),
        ("Indio", 45, "Cervezas", "🍽️"),
        ("Victoria", 45, "Cervezas", "🍽️"),
        ("Carta Blanca", 40, "Cervezas", "🍽️"),
        ("Modelo", 55, "Cervezas", "🍽️"),
        ("XX Lager", 45, "Cervezas", "🍽️"),
        ("Heineken ", 95, "Caguamas", "🍽️"),
        ("Indio ", 95, "Caguamas", "🍽️"),
        ("Victoria ", 95, "Caguamas", "🍽️"),
        ("Modelo ", 95, "Caguamas", "🍽️"),
        ("Vaso escarchado", 15, "Caguamas", "🍽️"),
        ("Vaso Michelada", 30, "Caguamas", "🍽️"),
        ("Coca Cola 600ml", 39, "Refrescos", "🍽️"),
        ("Coca Cola Lata", 35, "Refrescos", "🍽️"),
        ("Sangría 600ml", 35, "Refrescos", "🍽️"),
        ("Boing 500ml", 35, "Refrescos", "🍽️"),
        ("Agua Mineral 500ml", 35, "Refrescos", "🍽️"),
        ("Agua embotellada", 30, "Refrescos", "🍽️"),
        ("Cantarito", 75, "Refrescos", "🍽️"),
        ("Caballito Tequila", 70, "Refrescos", "🍽️"),
        ("Caballito Mezcal", 85, "Refrescos", "🍽️"),
        ("Café de olla", 35, "Bebidas Calientes/Postres", "🍽️"),
        ("Té", 35, "Bebidas Calientes/Postres", "🍽️"),
        ("Atole", 35, "Bebidas Calientes/Postres", "🍽️"),
        ("Ponche", 35, "Bebidas Calientes/Postres", "🍽️"),
        ("Cocol", 10, "Bebidas Calientes/Postres", "🍽️"),
        ("Pastel de Chocolate", 50, "Bebidas Calientes/Postres", "🍽️"),
    ]
    cur.executemany("INSERT INTO menu (nombre, precio, categoria, emoji, disponible) VALUES (?,?,?,?,1);", menu)

    # Extras
    extras = [("Limones", 10), ("Salsas", 10), ("Cebollitas", 15), ("Tortillas", 15), ("Queso extra", 20)]
    cur.executemany("INSERT INTO extras (nombre, precio) VALUES (?,?);", extras)

    conn.commit()
    conn.close()
    print("Base de datos creada en: " + DB_PATH)

if __name__ == "__main__":
    crear_bd()
